<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
  <h1>Faculty Registration Page</h1>
  Full Name <input type="text" name=""><br>
  Email<input type="email" name=""><br>
  Password<input type="password" name=""><br>
  
  <button name="button">Reg</button>
</body>
</html>