<!DOCTYPE html>
<html>
<head>

	<title></title>
</head>
<body>
  Home page<br>

  <a href="controller/adminController.php">Login</a>

  <a href="controller/facultyController.php">Reg</a>
</body>
</html>