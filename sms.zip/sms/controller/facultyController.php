<?php
header('location:../view/registration.php');
?>